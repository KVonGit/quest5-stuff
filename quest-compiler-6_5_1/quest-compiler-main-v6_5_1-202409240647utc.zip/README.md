Quest Compiler (version 6.5)
=======

**THIS PROJECT IS NO LONGER BEING DEVELOPED OR MAINTAINED!**

Quest Compiler takes in a [Quest 5](https://github.com/textadventures/quest) .quest file
and spits out a folder full of HTML, CSS and JS. It was used for turning Quest games into apps, as the output could be wrapped using tools like PhoneGap.

The source is being kept online here for the moment for reference, but it is **no longer being developed or maintained**.

Instead, [ThePix/QuestJS](https://github.com/ThePix/QuestJS) is a full re-write of Quest to pure JavaScript, and runs in the player's browser. 

