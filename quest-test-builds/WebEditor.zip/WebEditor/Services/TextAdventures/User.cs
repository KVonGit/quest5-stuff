﻿namespace TASessionManager
{
    public class User
    {
        public string UserId { get; set; }
    }
}
