QuestJS
=======

**THIS PROJECT IS NO LONGER BEING DEVELOPED OR MAINTAINED!**

QuestJS takes in a [Quest 5](https://github.com/textadventures/quest) .quest file
and spits out a folder full of HTML, CSS and JS. It was used for turning Quest games into apps, as the output can be wrapped using tools like PhoneGap.

The source is being kept online here for the moment for reference, but it is **no longer being developed or maintained**.

Instead, [Quest 6](https://github.com/textadventures/quest/tree/v6) is under development, which will provide a native JavaScript runtime for all Quest games which can run on any platform.
